# Importar los DTOs desde la carpeta DTO
import requests
from DTO.usuario_dto import UsuarioDTO
from DTO.accesorio_dto import AccesorioDTO
from DTO.tipo_dto import TipoDTO
from DAO.usuario_dao import UsuarioDAO
from DAO.accesorio_dao import AccesorioDAO
from DAO.tipo_dao import TipoDAO

def mostrar_menu_principal():
        print("="*60)
        print("MENÚ USUARIOS - TALCA PETS".center(60))
        print("="*60)
        print("1.- INICIAR SESIÓN")
        print("2.- REGISTRAR USUARIO")
        print("3.- SALIR")
        print("="*60)

def mostrar_menu_mantenedor():
    print("="*60)
    print("MANTENEDOR DE ACCESORIOS PARA MASCOTA".center(60))
    print("="*60)
    print("1.- (I) INGRESAR ACCESORIO")
    print("2.- (R) MOSTRAR ACCESORIOS")
    print("3.- (U) MODIFICAR ACCESORIO")
    print("4.- (D) ELIMINAR ACCESORIO")
    print("5.- (E) SALIR")
    print("="*60)

def mostrar_menu_mostrar():
    print("="*40)
    print("MENÚ MOSTRAR".center(40))
    print("="*40)
    print("1.- MOSTRAR LOS ACCESORIOS")
    print("2.- MOSTRAR UN ACCESORIO")
    print("3.- MOSTRAR PARCIAL")
    print("4.- VOLVER")
    print("="*40)    

def obtener_precio_dolar():
    try:
        response = requests.get('https://mindicador.cl/api')
        if response.status_code == 200:
            data = response.json()
            return data['dolar']['valor']
        return None
    except Exception as e:
        print(f"Error al obtener el precio del dólar: {e}")
        return None

def convertir_a_dolares(pesos):
    valor_dolar = obtener_precio_dolar()
    if valor_dolar:
        return round(pesos / valor_dolar, 2)
    return None

def registrar_usuario():
    try:
        print("\nREGISTRO DE USUARIO")
        print("="*30)
        username = input("Ingrese nombre de usuario: ")
        password = input("Ingrese contraseña: ")
        nombres = input("Ingrese nombres: ")
        apellidos = input("Ingrese apellidos: ")
        email = input("Ingrese email: ")
      
      # Crear el DTO con la contraseña sin hashear
        nuevo_usuario = UsuarioDTO(
            username=username,
            password_hash=password,  # La contraseña se hasheará en el DAO
            nombres=nombres,
            apellidos=apellidos,
            email=email,
            tipo_usuario='admin'  
        )   

        usuario_dao = UsuarioDAO()
        if usuario_dao.registrar(nuevo_usuario):
            print("\nUsuario registrado exitosamente")
            return True
        else:
            print("\nError al registrar usuario")
            return False
            
    except Exception as e:
        print(f"\nError en el registro: {e}")
        return False         

def iniciar_sesion():
    username = input("Ingrese su nombre de usuario")
    password = input("Ingrese su contraseña")
    
    usuario_dao = UsuarioDAO()

def menu_mantenedor():
    while True:
        mostrar_menu_mantenedor()
        opcion = input("Ingrese una opción: ")
        
        if opcion == "1":
            print('hola1')
        elif opcion == "2":
            print('hola2')
        elif opcion == "3":
            print('hola3')
        elif opcion == "4":
            print('hola4')
        elif opcion == "5":
            print('hola5')
        elif opcion == "6":
            break
        else:
            print("Opción no válida.")    


def main():
    while True:
        mostrar_menu_principal()
        opcion = input("Ingrese una opción: ")
        
        if opcion == "1":
            usuario = iniciar_sesion()
            if usuario and usuario.tipo_usuario.lower() == 'admin':
                menu_mantenedor()
                
        elif opcion == "2":
            registrar_usuario()
            
        elif opcion == "3":
            print("\nGracias por usar el sistema")
            break
        else:
            print("\nOpción inválida")

if __name__ == "__main__":
    mostrar_menu_principal()
