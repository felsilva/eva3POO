--crear la base de datos
CREATE DATABASE IF NOT EXIST talca_pets;
USE talca_pets;

--tabla tipo
CREATE TABLE IF NOT EXIST tipo (
    id_tipo INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL, 
    descripcion VARCHAR(255)

);

--tabla accesorio
CREATE TABLE IF NOT EXIST accesorio (
    id_accesorio INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    precio_dolar DECIMAL(10,2) NOT NULL,
    especie VARCHAR(50),
    descripcion VARCHAR(255),
    stock INT NOT NULL DEFAULT 0,
    peso DECIMAL(10,2),
    edad_recomendada VARCHAR(50),
    tipo_id INT,
    FOREIGNKEY(tipo_id) REFERENCES tipo(id_tipo)
);

--tabla usuario
CREATE TABLE IF NOT EXIST usuarios(
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(120) NOT NULL,
    nombres VARCHAR(100),
    apellidos VARCHAR(100),
    email VARCHAR(100),
    tipo_usuario ENUM('admin','cliente') DEFAULT 'cliente',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
